#include <wordset.h>

int Wordset::addmember(string s){
	     vector<string>vlist;
             s = "hello world! ";
             vlist.push_back(s);
             for (auto it = vlist.begin(); it != vlist.end(); ++it)
          cout <<" " << *it;
             
	return 0;
}
int Wordset :: deletemember(string s){

		if (find(vlist.begin(), vlist.end(),s) != vlist.end()) {

		cout << "Element found";
		vlist.pop_back();
		}

    		else {

       		cout << "Element not found";

   	 	}
		vlist.pop_back();
		cout<<"Deleting Member "<<endl;
    		for(string s :vlist)
    		cout<<s<<"  "<<endl;
		 return 0;
}
void Wordset :: displaylist(){
               vector<string>vlist;
             for (auto it = vlist.begin(); it != vlist.end(); ++it)
             cout <<" " << *it<<'\n"<<endl;
               cout <<"list is empty?"<<endl;
              // vector<string>vlist;
        cout <<"After deletion " << argc<<" arguments:" <<"\n";      
	for (int i = 1; i < argc; ++i){
        v1.vlist(argv[i]);
        }
	if(vlist.empty())
    		{
        	cout << "\n True";
    		}
    		else {
        	cout << "\n False";
    		}

}
