	 void emp::get()
