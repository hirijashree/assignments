#include <iostream>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
using namespace std;

int main()
{
  int i, status,N=50;
  pid_t pid;
  

  pid = fork();
  if (pid == 0)
    {
      for(i=1;i<50;i++)
        if(i%2 == 0)
          cout<<"child prints even number"<<i<<endl;
    }
  else
    {
      if (pid > 0)
        wait(0);
        pid = waitpid(pid, &status, 0);
      for(i=1;i<50;i++)
        if(i%2 != 0)
         cout<<"parent prints odd number"<<i<<endl;
         
    }
    
    
        if (WIFEXITED(status)  )  
        {
            cout<<"Child failed and terminates"<<endl;
           
            exit(1);
        }
        else if  (!WIFEXITED(status))  
        
            cout<<stderr<<"abnormal child termination"<<endl;
            exit(1);
        
        
        
    
 
  return 0;
  
}